#ifndef ELEVATOR_H
#define ELEVATOR_H

#include <string>

using namespace std;

class Elevator
{
    public:
        Elevator(int, int, int);
        void move(int);
        void load(int);
        void unload(int);

    private:
        string status; // Options are moving, stopped, underMaintenance
        int levels;
        int currentLevel; // Starts from 0, representing ground
        int maximumNumberOfPeople; //
        int currentNumberOfPeople; //number of people
};

#endif // ELEVATOR_H
