#include "Elevator.h"
#include <iostream>
#include <cstdlib>
#include <unistd.h>
#include <dos.h> //for delay

using namespace std;

Elevator::Elevator(int levels, int numberLimit, int currentLevel)
{
    this->levels = levels;
    this->maximumNumberOfPeople = numberLimit;
    if (currentLevel>levels)
    {
        cout<<"\nThere are only "<<levels<<" levels. Current level cannot be "<<currentLevel<<endl;
        cout<<"Current level set to 0"<<endl;
        this->currentLevel = 0;
    }
    else
    {
        this->currentLevel = currentLevel;
    }
    this->currentNumberOfPeople = 0;
}

void Elevator::move(int level)
{
    if(this->currentNumberOfPeople>this->maximumNumberOfPeople)
    {
        cout<<"Maximum elevator capacity is: "<<this->maximumNumberOfPeople<<endl;
        cout<<"There are "<<this->currentNumberOfPeople<<" people in the elevator. Please unload"<<endl;
    }
    else if(this->currentNumberOfPeople==0){
        cout<<"Cannot move. No one in elevator\n Please load first"<<endl;
    }
    else
    {
        if( level > this->levels )
        {
            cout<<"There are only "<< this->levels <<" floors"<<endl;
        }
        else if ( level < 0 )
        {
            cout<<"Floor number can't be negative"<<endl;
        }
        else
        {
            int moves = level - this->currentLevel;

            if(moves>0)
            {

                for(int i=0;i<moves;i++)
                {
                    this->currentLevel = this->currentLevel + 1;
                    cout<<"MOVING UP; Current Level: "<< this->currentLevel<<endl;
                }
            }
            else
            {
                for(int i=moves;i<0;i++)
                {
                    this->currentLevel = this->currentLevel - 1;
                    cout<<"MOVING DOWN; Current Level: "<< this->currentLevel<<endl;
                }
            }

            cout<<"DOOR OPENS. YOU HAVE ARRIVED;  Current Level: "<< this->currentLevel<<endl;

        }
    }
}

void Elevator::load(int numberOfPeople)
{
    this->currentNumberOfPeople = this->currentNumberOfPeople + numberOfPeople;
    cout<<"\n"<<numberOfPeople<<" people joined the elevator"<<endl;
    cout<<"Current number of people in elevator: "<<this->currentNumberOfPeople<<endl;
}

void Elevator::unload(int numberOfPeople)
{
    if(this->currentNumberOfPeople - numberOfPeople<0)
    {
        cout<<"\nCannot take out"<<numberOfPeople<<" when there's only "<<this->currentNumberOfPeople<<" in the elevator"<<endl;
    }
    else
    {
        this->currentNumberOfPeople = this->currentNumberOfPeople - numberOfPeople;
        cout<<"\n"<<numberOfPeople<<" people have been taken out of the elevator. \n"<<this->currentNumberOfPeople<<"people are left in the elevator"<<endl;
    }
}
