#include <iostream>
#include <windows.h>
#include "Elevator.h"

using namespace std;

void coloured_print(string, int);
int get_option();

int main()
{
    int levels;
    int max_people;
    int current_level;
    int num_people;


    system("Color 0A");
    cout<<"|| PLEASE INITIALIZE YOUR ELEVATOR ||\n"<<endl;
    cout<<"Enter the number of levels the elevator has access to: ";
    cin>>levels;

    cout<<"Enter the maximum number of people allowed per elevator ride: ";
    cin>>max_people;

    cout<<"Enter starting level [What level is the elevator starting from]: ";
    cin>>current_level;


    Elevator elev(levels,max_people,current_level);
    cout<<"\n|| ELEVATOR INITIALIZED ||"<<endl;

    cout<<"Elevator simulation has begun....."<<endl;
    while (true)
    {
        int option = get_option();
        if(option==1)
        {
            int num;
            cout<<"How many people do you want to join the elevator: ";
            cin>>num;

            elev.load(num);
        }
        else if(option==2)
        {
            int num;
            cout<<"How many people do you want to remove from the elevator: ";
            cin>>num;

            elev.unload(num);
        }
        else if(option==3)
        {
            int num;
            cout<<"What level do you want to move to: ";
            cin>>num;

            elev.move(num);
        }
        else if(option==4)
        {
            break;
        }
        else
        {
            cout<<"Invalid option"<<endl;
        }
    }

    return 0;
}

int get_option(){

    int option;
    cout<<"\n === OPTIONS === "<<endl;
    cout<<"1. \t"<<"Load (Make people enter elevator)"<<endl;
    cout<<"2. \t"<<"Unload (Remove people from the elevator)"<<endl;
    cout<<"3. \t"<<"Move (Move elevator to a level of your choice)"<<endl;
    cout<<"4. \t"<<"End Simulation"<<endl;

    cout<<"\nYour choice: ";
    cin>>option;

    return option;
}

void coloured_print(string text, int color_code){
    cout<<"\033[1;31mbold "<<text<<"\033[0m\n"<<endl;
}
